import { useState } from "react";

interface Location {
  lat: number;
  lng: number;
}

export function useLocation() {

  const [location, setLocation] =
    useState<Location | null>(null);



  function getLocation(
    callback?: (location: Location) => void
  ) {

    navigator.geolocation.getCurrentPosition(

      (position) => {

        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };


        setLocation(newLocation);


        if (callback) {
          callback(newLocation);
        }

      },


      (error) => {

        console.error(error);

      }

    );

  }



  function clearLocation() {

    setLocation(null);

  }



  return {
    location,
    getLocation,
    clearLocation,
  };

}