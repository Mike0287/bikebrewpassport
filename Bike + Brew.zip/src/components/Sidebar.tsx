interface SidebarProps {
  search: string;
  setSearch: (value: string) => void;
}

export default function Sidebar({
  search,
  setSearch,
}: SidebarProps) {

  return (
    <aside className="sidebar">

      <h1>🏍 Bike + Brew</h1>

      <h2>
        Passport Companion
      </h2>


      <input
        type="text"
        placeholder="Search venues..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

    </aside>
  );
}