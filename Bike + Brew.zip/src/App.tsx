import MapView from "./components/MapView";
import Sidebar from "./components/Sidebar";
import NextStop from "./components/NextStop";
import Progress from "./components/Progress";
import { useVenues } from "./hooks/useVenues";
import { useState } from "react";
import { useVisited } from "./hooks/useVisited";
import { useLocation } from "./hooks/useLocation";
import type { Venue } from "./hooks/useVenues";


function App() {

  const venues = useVenues();

  const {
    location,
    getLocation,
    clearLocation
  } = useLocation();

  const { visited, toggleVisited } = useVisited();


  const [search, setSearch] = useState("");

  const [region, setRegion] = useState("");

  const [nextStop, setNextStop] =
    useState<Venue | null>(null);


  const [resetMap, setResetMap] =
    useState(0);

  const [mobilePanelOpen, setMobilePanelOpen] =
    useState(false);



  function clearNextStop() {

    setNextStop(null);

    clearLocation();

    setResetMap(prev => prev + 1);

  }



  const filteredVenues = venues.filter((venue) =>
    venue["Venue Name"]
      .toLowerCase()
      .includes(search.toLowerCase())
    &&
    (
      region === "" ||
      venue.Region === region
    )
  );



  return (

    <div className="app">

      <button
        className="mobile-drawer-toggle"
        type="button"
        onClick={() => setMobilePanelOpen((isOpen) => !isOpen)}
        aria-expanded={mobilePanelOpen}
        aria-controls="ride-controls"
        aria-label={mobilePanelOpen ? "Close ride controls" : "Open ride controls"}
      >
        ☰
      </button>

      <div
        className={`sidebar-container ${
          mobilePanelOpen ? "mobile-panel-open" : ""
        }`}
      >

        <button
          className="mobile-panel-toggle"
          type="button"
          onClick={() => setMobilePanelOpen((isOpen) => !isOpen)}
          aria-expanded={mobilePanelOpen}
          aria-controls="ride-controls"
        >
          <span className="mobile-panel-handle" aria-hidden="true" />
          {mobilePanelOpen ? "Hide ride controls" : "Show ride controls"}
        </button>

        <div id="ride-controls" className="sidebar-content">
          <Sidebar
            search={search}
            setSearch={setSearch}
          />



          <Progress
            venues={venues}
            visited={visited}
            region={region}
            setRegion={setRegion}
            onRegionSelected={() => setMobilePanelOpen(false)}
          />



          <NextStop
            venues={venues}
            visited={visited}
            region={region}
            location={location}
            getLocation={getLocation}
            nextStop={nextStop}
            setNextStop={setNextStop}
            clearNextStop={clearNextStop}
          />
        </div>


      </div>




      <MapView
        venues={filteredVenues}
        visited={visited}
        toggleVisited={toggleVisited}
        location={location}
        nextStop={nextStop}
        resetMap={resetMap}
      />


    </div>

  );

}

export default App;
